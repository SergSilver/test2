function getNews() {
    var res = $http.get(encodeURI("http://newsapi.org/v2/top-headlines?q=коронавирус"),
    {
        headers: {
            "x-api-key": "a39c47528bea4c8684aeeeb2b11669ef"
        }
    }
    );
    if (res) {
        return res.data.articles[0];
    } else
        return "А и нет новостей"
}